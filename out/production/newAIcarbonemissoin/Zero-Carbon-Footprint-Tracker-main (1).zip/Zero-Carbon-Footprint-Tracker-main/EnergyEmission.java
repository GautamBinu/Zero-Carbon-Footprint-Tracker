public class EnergyEmission extends EmissionSource{
    private double kWhused;
    private String energySource;

    /**
     * Constructor for EnergyEmission
     * @param sourceID
     * @param category
     * @param date
     * @param userName
     * @param kWhused
     * @param energySource
     */

    public EnergyEmission(String sourceID, String category, String date, String userName,double  kWhused, String energySource){
        super(sourceID, category, date, userName);
        this.kWhused=kWhused;
        this.energySource=energySource;

    }

    /**
     * Get the value of kWHused
     * @return return the value of kWhused
     */
    public double getKwhused(){
        return this.kWhused;
    }
    /**
     * Set the value of kWhused
     *  @param kWhused
     */
    public void setKwhused(double kWhused){
        this.kWhused=kWhused;
    }
    /**
     * Get the value of energySource
     * @return return the value of energySource
     */
    public String getEnergySource(){
        return this.energySource;
    }
    /**
     * Set the value of energySource
     * @param energySource
     */
    public void setEnergySource(String energySource){
        this.energySource=energySource;
    }


    /**
     * 
     * 
     * Calculate the emission based on the energy source and the kWH used. 
     * The emission factor for;
     * grid=0.404
     * solar=0.050
     * wind= 0.025
     * If the energy source is not recognized, the emission factor is 0.0.
     * @return the total emission in kg CO2 based on the energy source and the kWH used. If the energy source is not recognized, an IllegalArgumentException is thrown.
     */
    @Override
    public double calculateEmission(){

        double energyFactor=0.0;
        energySource=energySource.toLowerCase();

        if (energySource.equals("grid")){
            energyFactor=0.404;

        }
        else if (energySource.equals("solar")){
            energyFactor=0.050;

        }
        else if (energySource.equals("wind")){
            energyFactor=0.025;
        }
        else{
            throw new IllegalArgumentException("Invalid energy source: "+energySource);
        }
        return kWhused*energyFactor;
    }

    /**
     * Override the toString method to include the energy source and kWH used in the string representation of the EnergyEmission object.
     */
    @Override
    public String toString(){
        return String.format("%s | %s, %.1f kWh | %.2f kg CO2", 
                super.toString(), 
                energySource, 
                kWhused, 
                calculateEmission());
    }
            
    
}
